import React from 'react';


const Checkout = props => {
    return (
        <div>

        </div>
    )
}


export default Checkout;