import React from 'react';
import {NavLink} from 'react-router-dom';
import { Navbar, NavbarBrand, Nav, NavItem } from 'reactstrap';
import './Header.css';
import logo from '../../assets/logo.png';



function Header() {
    return(
        <div className="Navigation">
            <Navbar style={{backgroundColor: "#D70F64",hight : "80px"}}>
                <NavbarBrand href="/" className="mr-auto ml-md-5 Brand">
                    <img src={logo} alt="burgerbuilder" width="60px" />
                </NavbarBrand>
                <Nav Nav className = "mr-md-5" >
                    <NavItem>
                        <NavLink exact to="/" className="NavLink">Burger Builder</NavLink>
                    </NavItem>
                    <NavItem>
                        <NavLink exact to="/orders" className="NavLink">Orders</NavLink>
                    </NavItem>
                </Nav>
            </Navbar>
        </div>
    );
}


export default Header;